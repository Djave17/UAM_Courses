import UIKit

class Onboarding3ViewController: UIViewController {
    
    private let slider = UISlider() // Slider =
    private let sliderBackgroundView = UIView() // view del slider
    private let instructionLabel = UILabel() // label de inicio
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Comprobando que srive pongo ofndo blacno
        view.backgroundColor = .white
        
        // Configuracion del fondo
        sliderBackgroundView.backgroundColor = .systemTeal //color uam
        sliderBackgroundView.layer.cornerRadius = 12
        sliderBackgroundView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(sliderBackgroundView)
        
        // Configuracion del slider
        slider.minimumValue = 0
        slider.maximumValue = 1
        slider.value = 0 // Valor inicial
        slider.minimumTrackTintColor = .clear // Hacer invisible la pista mínima
        slider.maximumTrackTintColor = .clear // Hacer invisible la pista máxima
        slider.thumbTintColor = .white // Color de la bolita
        slider.translatesAutoresizingMaskIntoConstraints = false
        
        // Cierre al cambio de valor
        slider.addAction(UIAction(handler: { [weak self] _ in
            guard let self = self else { return }
            if self.slider.value >= 0.95 { // Detectar si se deslizó casi al final
                self.slider.value = 1 // Fijar el slider al máximo
            }
        }), for: .valueChanged)
        
        view.addSubview(slider)
        
        //label
        instructionLabel.text = "Desliza para comenzar"
        instructionLabel.textColor = .white
        instructionLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        instructionLabel.textAlignment = .center
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        sliderBackgroundView.addSubview(instructionLabel) // Label dentro del slider
        
        // Constraints
        NSLayoutConstraint.activate([
            // Pongo mas abajo todo
            sliderBackgroundView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            sliderBackgroundView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -80), // mas abajo
            sliderBackgroundView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            sliderBackgroundView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            sliderBackgroundView.heightAnchor.constraint(equalToConstant: 40), // altura ala vista del background
            
            // slider dentro delfondo teal
            slider.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            slider.centerYAnchor.constraint(equalTo: sliderBackgroundView.centerYAnchor), //slider centrado en el fondo
            slider.leadingAnchor.constraint(equalTo: sliderBackgroundView.leadingAnchor),
            slider.trailingAnchor.constraint(equalTo: sliderBackgroundView.trailingAnchor),
            slider.heightAnchor.constraint(equalToConstant: 20), // tamaño del slider
            
            // etiqueta dentro del slider en el centro
            instructionLabel.centerXAnchor.constraint(equalTo: sliderBackgroundView.centerXAnchor),
            instructionLabel.centerYAnchor.constraint(equalTo: sliderBackgroundView.centerYAnchor),
            instructionLabel.leadingAnchor.constraint(greaterThanOrEqualTo: sliderBackgroundView.leadingAnchor, constant: 10),
            instructionLabel.trailingAnchor.constraint(lessThanOrEqualTo: sliderBackgroundView.trailingAnchor, constant: -10)
        ])
    }
}
