//
//  LoginController.swift
//  AppGestionUAM
//
//  Created by David Sanchez on 20/11/24.
//

import Foundation

final class LoginController {
    private let apiDataSource = APIClient()
    
  //  func login(email: String, password: String) async -> Result<LoginResponse, APIError> {
      //      return await apiDataSource.logIn(email: email, password: password)
   // }
}
