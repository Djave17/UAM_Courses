//
//  QuestionLogInViewController.swift
//  AppGestionUAM
//
//  Created by Kristel Geraldine Villalta Porras on 11/1/25.
//

import UIKit

class QuestionLogInViewController: UIViewController {

    //Outlets
    
    @IBOutlet weak var vwQuestion: UIView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // MARK: Design of Views
        vwQuestion.layer.cornerRadius = 20
    }

    

}
