import UIKit
import AVFoundation // Importa AVFoundation para poder usar AVAudioPlayer

class LauncherViewController: UIViewController {
    
    // Outlets
    @IBOutlet weak var rotatingImageView: UIImageView!
    
    // Reproductor de audio
    var audioPlayer: AVAudioPlayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        rotateImage() // Comienza la rotación
        navigateToOnboarding() // Navega a la siguiente vista después de 6 segundos
        playSound() // Reproduce el sonido
    }
    
    func playSound() {
        do {
            // Configura el AVAudioSession para asegurarse de que el audio se reproduzca correctamente
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [])
            try AVAudioSession.sharedInstance().setActive(true)
            
            // Verificar si el archivo está en el bundle
            if let soundURL = Bundle.main.url(forResource: "agua", withExtension: "mp3", subdirectory: "Resources/Sonido") {
                // Crea el reproductor de audio
                audioPlayer = try AVAudioPlayer(contentsOf: soundURL)
                audioPlayer?.play() // Reproduce el sonido
                audioPlayer?.numberOfLoops = -1 // Hace que el sonido se repita indefinidamente
            } else {
                // Si no se encuentra el archivo, imprime la ruta para verificar si el archivo está en el bundle
                if let filePath = Bundle.main.path(forResource: "agua", ofType: "mp3", inDirectory: "Resources/Sonido") {
                    print("Archivo encontrado en: \(filePath)")
                } else {
                    print("No se encontró el archivo de sonido.")
                }
            }
        } catch {
            print("Error al intentar configurar el AVAudioSession o reproducir el sonido: \(error)")
        }
    }

    func rotateImage() {
        // Realiza una rotación completa de 360 grados en 2 segundos
        let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation.z")
        rotationAnimation.fromValue = 0
        rotationAnimation.toValue = CGFloat.pi * 2
        // Duración de una vuelta completa
        rotationAnimation.duration = 2.0
        // Bucle infinito
        rotationAnimation.repeatCount = .infinity
        // Animación de Giro
        rotatingImageView.layer.add(rotationAnimation, forKey: "rotateAnimation")
    }
    
    func navigateToOnboarding() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 6.0) {
            // Carga la vista de Onboarding1 desde un archivo XIB
            let onboardingVC = Onboarding1ViewController(nibName: "Onboarding1ViewController", bundle: nil)
            onboardingVC.modalPresentationStyle = .fullScreen
            self.present(onboardingVC, animated: true, completion: nil)
        }
    }
}

