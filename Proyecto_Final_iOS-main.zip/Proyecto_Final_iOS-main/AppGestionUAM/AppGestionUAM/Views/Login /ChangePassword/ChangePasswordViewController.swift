//
//  ChangePasswordViewController.swift
//  AppGestionUAM
//
//  Created by Kristel Geraldine Villalta Porras on 11/1/25.
//

import UIKit

class ChangePasswordViewController: UIViewController {

    @IBOutlet weak var btnChangePassword: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()

        btnChangePassword.layer.cornerRadius = 10
    }
    
    

}
