//
//  SettingsViewController.swift
//  AppGestionUAM
//
//  Created by Kristel Geraldine Villalta Porras on 11/1/25.
//

import UIKit
import AVFoundation

class SettingsViewController: UIViewController {
    
    // Reproductor de video
    var player: AVPlayer?

    var playerLayer: AVPlayerLayer?
    
    @IBOutlet weak var stackViewButtona: UIStackView!
    let apiClient = APIClient()

    @IBOutlet weak var btnHome: UIButton!
    var isFilled = false
    
    //Outlets
    
    @IBOutlet weak var imageUser: UIImageView!
    
    @IBOutlet weak var themeSwitch: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // LLamo la funcion de configuracion del vd
        setupVideoPlayer()
        
        //Lee el estado del swicth
        let isDarkMode = UserDefaults.standard.bool(forKey: "isDarkMode")
           themeSwitch.isOn = isDarkMode
           overrideUserInterfaceStyle = isDarkMode ? .dark : .light
        
        self.title = "Ajustes"
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.titleTextAttributes = [.foregroundColor: UIColor.systemTeal]
        navigationController?.navigationBar.standardAppearance = appearance
        navigationController?.navigationBar.scrollEdgeAppearance = appearance
        
        setupUI()

        //Log Out Configuracion con Alerta
    }
    
    //MARK: - Function VideoPlayer
    private func setupVideoPlayer() {
        // Ruta del video en el bundle
        guard let videoPath = Bundle.main.path(forResource: "vd_GearUser", ofType: "mov") else {
            print("Error: No se encontró el video vd_GearUser.mov en el bundle.")
            return
        }
        
        // Crear la URL del video
        let videoURL = URL(fileURLWithPath: videoPath)
        
        // Crear el reproductor
        player = AVPlayer(url: videoURL)
        player?.actionAtItemEnd = .none // Evitar detener el video al terminar
        
        // Inicializar el playerLayer antes de usarlo
        playerLayer = AVPlayerLayer(player: player)
        
        // Tamaño ajustado - ancho + altura
        let videoWidth = view.frame.width * 0.3
        let videoHeight = view.frame.height * 0.15
        
        // centro arriba video
        let centerX = (view.frame.width - videoWidth) / 2
        let centerY = view.frame.height * 0.15 // más arriba
        
        playerLayer?.frame = CGRect(x: centerX, y: centerY, width: videoWidth, height: videoHeight)
        playerLayer?.videoGravity = .resizeAspectFill
        
        // video subcapa
        if let playerLayer = playerLayer {
            view.layer.insertSublayer(playerLayer, at: 0)
        }
        
        // bucle cuando termina el video
        NotificationCenter.default.addObserver(self, selector: #selector(restartVideo), name: .AVPlayerItemDidPlayToEndTime, object: player?.currentItem)
        
        // Reproducir automáticamente
        player?.play()
    }
    
    // Reiniciar el video cuando termine
    @objc private func restartVideo() {
        player?.seek(to: .zero)
        player?.play()
    }
    
    deinit {
        // Eliminar el observador para evitar problemas de memoria
        NotificationCenter.default.removeObserver(self)
    }

    //MARK: - Navegation
    
    
    @IBAction func btnHom(_ sender: Any) {
        isFilled.toggle() // Alterna entre true y false
                let newImage = UIImage(systemName: isFilled ? "house.fill" : "house")
        btnHome.setImage(newImage, for: .normal)
        
        let nav = CourseListViewController()
        navigationController?.pushViewController(nav, animated: true)
    }
    
    @IBAction func btnProfile(_ sender: Any) {
        let navProfile = ProfileViewController()
        navigationController?.pushViewController(navProfile, animated: true)
    }
    
    @IBAction func btnLanguage(_ sender: Any) {
        let navLanguage = LanguagesViewController()
        navigationController?.pushViewController(navLanguage, animated: true)
    }
    
    @IBAction func btnChangePasswrod(_ sender: Any) {
        let navChangePass = ChangePassViewController()
        navigationController?.pushViewController(navChangePass, animated: true)
    }
    
    @IBAction func btnContact(_ sender: Any) {
        let navContact = ContactViewController()
        navigationController?.pushViewController(navContact, animated: true)
    }
    
    
    @IBAction func btnProfiles(_ sender: Any) {
        let navContact = ProfileViewController()
        navigationController?.pushViewController(navContact, animated: true)
    }
    
    
    @IBAction func btnChgPass(_ sender: Any) {
        let navContact = ChangePassViewController()
        navigationController?.pushViewController(navContact, animated: true)
    }
    
    @IBAction func btnLanguages(_ sender: Any) {
        let navContact = LanguagesViewController()
        navigationController?.pushViewController(navContact, animated: true)
    }

    @IBAction func btnContactMe(_ sender: Any) {
        let navContact = ContactViewController()
        navigationController?.pushViewController(navContact, animated: true)
    }
    
    
    @IBAction func btnLogOutt(_ sender: Any) {
        let navLogin = LoginViewController()
        navigationController?.pushViewController(navLogin, animated: true)
        apiClient.deleteToken()
    }
    
    
    @IBAction func tappedOnDarkMode(_ sender: Any) {
            guard let switchControl = sender as? UISwitch else { return }
            
            let isDark = switchControl.isOn
            overrideUserInterfaceStyle = isDark ? .dark : .light

            // Guardar la preferencia del usuario
            UserDefaults.standard.set(isDark, forKey: "isDarkMode")
    }
    
    
    @IBAction func tappedOnLogOut(_ sender: Any) {
        
        let navLogin = LoginViewController()
        navigationController?.pushViewController(navLogin, animated: true)
        apiClient.deleteToken()
    }
    
    //MARK: - UI
    func setupUI() {
        // Setup SearchBar
        
        
        
        
        
        // Setup StackView
        stackViewButtona.layer.cornerRadius = 25
        stackViewButtona.clipsToBounds = true
        stackViewButtona.layer.shadowColor = UIColor.black.cgColor
        stackViewButtona.layer.shadowOffset = CGSize(width: 0, height: 2)
        stackViewButtona.layer.shadowRadius = 4
        stackViewButtona.layer.shadowOpacity = 0.1
        
        navigationItem.hidesBackButton = true
        
        
    }
    
}
