//
//  ViewController.swift
//  AppGestionUAM
//
//  Created by David Sanchez on 31/10/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var courseListButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "App Gestion UAM"
        
        
        
//    }
//    
//    @IBAction func tapOnCourseList(_ sender: Any) {
//        
//        let courseListViewController = CourseListViewController()
//        
//        navigationController?.pushViewController(courseListViewController, animated: true)
  }
//    

}

