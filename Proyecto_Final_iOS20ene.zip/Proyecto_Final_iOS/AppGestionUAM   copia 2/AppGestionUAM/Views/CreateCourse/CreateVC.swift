//
//  CreateVC.swift
//  AppGestionUAM
//
//  Created by Kristel Geraldine Villalta Porras on 17/1/25.
//

import UIKit

class CreateVC: UIViewController {

    @IBOutlet weak var btnSaveCreate: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
          // Asegúrate de que el botón tenga un tamaño cuadrado
          let buttonSize = min(btnSaveCreate.frame.width, btnSaveCreate.frame.height)
          btnSaveCreate.frame.size = CGSize(width: buttonSize, height: buttonSize)
          
          // Hacerlo circular
          btnSaveCreate.layer.cornerRadius = buttonSize / 2
          btnSaveCreate.clipsToBounds = true
    }


}
