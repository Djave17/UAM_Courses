//
//  Onboarding1ViewController.swift
//  AppGestionUAM
//
//  Created by Kristel Geraldine Villalta Porras on 13/1/25.
//

import UIKit

class Onboarding1ViewController: UIViewController {

    @IBOutlet weak var btnSig: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Configurar el estilo del botón
        btnSig.layer.cornerRadius = 10
    }

    // Usando @IBAction para vincular el botón desde el storyboard
   
    }

