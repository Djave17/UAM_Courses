import UIKit
import AVKit
import AVFoundation

class Onboarding1ViewController: UIViewController {
    
    // Reproductor de video
    var player: AVPlayer?
    
    // Outlets txtView
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var txtvwOb1: UITextView!
    @IBOutlet weak var txtvwTitle: UITextView!
    
    var playerLayer: AVPlayerLayer?
    
    let progressBar = CircularProgressBar(frame: CGRect(x: 0, y: 0, width: 100, height: 100)) // Barra de progreso
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Desactivando interacción con Text View Descripcion
        txtvwOb1.isScrollEnabled = false
        txtvwOb1.isEditable = false
        txtvwOb1.isSelectable = false
        
        // Desactivando interacción con Text View Title
        txtvwTitle.isScrollEnabled = false
        txtvwTitle.isEditable = false
        txtvwTitle.isSelectable = false
        
        // Aseguramos que el botón tenga un tamaño adecuado
            let buttonWidth = continueButton.frame.size.width
            let buttonHeight = continueButton.frame.size.height

            // Hacemos que el botón tenga más curvatura en los bordes superior e inferior
            continueButton.layer.cornerRadius = buttonHeight / 2  // Curvatura más pronunciada
            continueButton.clipsToBounds = true

            // Usamos maskedCorners para redondear solo las esquinas superior e inferior
            continueButton.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner, .layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        continueButton.clipsToBounds = true
        
        // Configuración del video
        setupVideoPlayer()
        hideBackButton()
        setupProgressBar() // Configuración de la barra de progreso
        
        // Iniciar la barra de progreso con 33.33%
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.progressBar.setProgress(0.3333) // 33.33% de progreso
        }
    }
    
    // Configurar la barra de progreso circular
    private func setupProgressBar() {
        let screenHeight = view.bounds.height
        let yOffset = screenHeight * 0.90 //ma abajo
        
        progressBar.center = CGPoint(x: view.center.x, y: yOffset)
        view.addSubview(progressBar)
    }
    
    // Navegación
    @IBAction func navv(_ sender: Any) {
        let onboarding2 = Onboarding2ViewController()
        onboarding2.navigationItem.hidesBackButton = true // Oculta el botón de "Back"
        navigationController?.pushViewController(onboarding2, animated: true)
    }
    
    
    @IBAction func saltarTapped(_ sender: Any) {
        let loginButton = LoginViewController()
        navigationController?.pushViewController(loginButton, animated: true)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopVideo() // Detener el video al salir de la vista
    }
    
    private func setupVideoPlayer() {
        // Ruta del video en el bundle
        guard let videoPath = Bundle.main.path(forResource: "vd_Onb1", ofType: "mov") else {
            print("Error: No se encontró el video vd_Onb3.mov en el bundle.")
            return
        }
        
        // Crear la URL del video
        let videoURL = URL(fileURLWithPath: videoPath)
        
        // Crear el reproductor
        player = AVPlayer(url: videoURL)
        player?.actionAtItemEnd = .none // Evitar detener el video al terminar
        
        // Inicializar el playerLayer antes de usarlo
        playerLayer = AVPlayerLayer(player: player)
        
        // Tamaño ajustado - ancho +altur
        let videoWidth = view.frame.width * 0.4
        let videoHeight = videoWidth * 12 / 9
        
        // centro arriba vidio
        let centerX = (view.frame.width - videoWidth) / 2
        let centerY = (view.frame.height - videoHeight) / 3 // ma arriba
        
        playerLayer?.frame = CGRect(x: centerX, y: centerY, width: videoWidth, height: videoHeight)
        playerLayer?.videoGravity = .resizeAspectFill
        
        // vidio subcapa
        if let playerLayer = playerLayer {
            view.layer.insertSublayer(playerLayer, at: 0)
        }
        
        // buclecuando temrina el vidio
        NotificationCenter.default.addObserver(self, selector: #selector(restartVideo), name: .AVPlayerItemDidPlayToEndTime, object: player?.currentItem)
        
        // Reproducir automáticamente
        player?.play()
    }
    
    // Reiniciar el video cuando termine
    @objc private func restartVideo() {
        player?.seek(to: .zero)
        player?.play()
    }
    
    deinit {
        // Eliminar el observador para evitar problemas de memoria
        NotificationCenter.default.removeObserver(self)
    }
    
    func stopVideo() {
        player?.pause()
        player?.replaceCurrentItem(with: nil) // Libera el video cargado
        playerLayer?.removeFromSuperlayer() // Elimina el layer del video
        
        // Asigna nil para liberar memoria
        player = nil
        playerLayer = nil
    }
}

//MARK: - Clase del Progress Bar Circular
class CircularProgressBar: UIView {
    
    private let progressLayer = CAShapeLayer()
    private let trackLayer = CAShapeLayer()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayers()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupLayers()
    }
    
    private func setupLayers() {
        let radius = bounds.width / 2.5
        let circularPath = UIBezierPath(arcCenter: CGPoint(x: bounds.midX, y: bounds.midY),
                                        radius: radius,
                                        startAngle: -CGFloat.pi / 2,
                                        endAngle: 1.5 * CGFloat.pi,
                                        clockwise: true)

        trackLayer.path = circularPath.cgPath
        trackLayer.strokeColor = UIColor.lightGray.withAlphaComponent(0.3).cgColor
        trackLayer.fillColor = UIColor.clear.cgColor
        trackLayer.lineWidth = 3  // delgado
        trackLayer.lineCap = .round
        layer.addSublayer(trackLayer)
        
        // animacion
        progressLayer.path = circularPath.cgPath
        progressLayer.strokeColor = UIColor.systemTeal.cgColor
        progressLayer.fillColor = UIColor.clear.cgColor
        progressLayer.lineWidth = 3  // Más delgado
        progressLayer.lineCap = .round
        progressLayer.strokeEnd = 0  // Inicialmente en 0%
        layer.addSublayer(progressLayer)
    }
    
    func setProgress(_ value: CGFloat, animated: Bool = true, duration: CFTimeInterval = 1.0) {
        let clampedValue = max(0, min(value, 1))
        let animation = CABasicAnimation(keyPath: "strokeEnd")
        animation.fromValue = progressLayer.strokeEnd
        animation.toValue = clampedValue
        animation.duration = animated ? duration : 0
        progressLayer.strokeEnd = clampedValue
        progressLayer.add(animation, forKey: "progressAnim")
    }
}
