//
//  APIError.swift
//  AppGestionUAM
//
//  Created by David Sanchez on 16/11/24.
//

enum APIError: Error {
    case invalidCredentials
    case invalidResponse          // Respuesta no válida del servidor
    case invalidURL               // URL malformada
    case encodingFailed           // Error al codificar los datos
    case noData                   // Respuesta vacía del servidor
    case decodingFailed           // Error al decodificar la respuesta
    case validationFailed(String) // Error de validación con mensaje específico
    case serverError(String)
    case userResgistered
    case decodingError
    case networkError
    
    case unknownError
}
