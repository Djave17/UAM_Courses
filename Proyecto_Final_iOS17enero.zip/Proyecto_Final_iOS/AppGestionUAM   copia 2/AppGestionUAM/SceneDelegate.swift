//
//  SceneDelegate.swift
//  AppGestionUAM
//
//  Created by David Sanchez on 31/10/24.
//

import UIKit

class SceneDelegate: UIResponder, UIWindowSceneDelegate {

    var window: UIWindow?

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        // Crear la ventana principal
        let window = UIWindow(windowScene: windowScene)
        
        // Establecer CreateViewController como el controlador raíz
        let CreateVC = CreateVC()
        let navigationController = UINavigationController(rootViewController: CreateVC)
        window.rootViewController = navigationController
        
        // Hacer visible la ventana
        self.window = window
        window.makeKeyAndVisible()
    }

    func sceneDidDisconnect(_ scene: UIScene) {
        // Llamado cuando la escena se desconecta.
    }

    func sceneDidBecomeActive(_ scene: UIScene) {
        // Llamado cuando la escena pasa de inactiva a activa.
    }

    func sceneWillResignActive(_ scene: UIScene) {
        // Llamado cuando la escena pasará de activa a inactiva.
    }

    func sceneWillEnterForeground(_ scene: UIScene) {
        // Llamado cuando la escena pasa del fondo al primer plano.
    }

    func sceneDidEnterBackground(_ scene: UIScene) {
        // Llamado cuando la escena pasa de primer plano al fondo.
    }
}
