//
//  RegisterViewModel.swift
//  AppGestionUAM
//
//  Created by David Sanchez on 17/11/24.
//

import Foundation

class RegisterViewModel: ObservableObject {
    @Published var name: String = ""
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var isRegistered = false
    @Published var errorMessage: String?

    func registerUser() async {
        guard !name.isEmpty, !email.isEmpty, !password.isEmpty else {
            errorMessage = "Por favor, completa todos los campos."
            return
        }

        do {
            // Llamada al APIClient para el registro
            let authResponse = try await APIClient.shared.register(name: name, email: email, password: password)
            DispatchQueue.main.async {
                self.isRegistered = true
                self.errorMessage = nil
                print("Registro exitoso: \(authResponse.user.name)")
            }
        } catch let apiError as APIError {
            DispatchQueue.main.async {
                self.isRegistered = false
                switch apiError {
                case .validationFailed(let message):
                    self.errorMessage = message
                case .userResgistered:
                    self.errorMessage = "El usuario ya existe. Por favor, inicia sesión."
                default:
                    self.errorMessage = "Ocurrió un error: \(apiError.localizedDescription)"
                }
            }
        } catch {
            DispatchQueue.main.async {
                self.isRegistered = false
                self.errorMessage = "Error desconocido: \(error.localizedDescription)"
            }
        }
    }
}
