//
//  LoginViewController.swift
//  AppGestionUAM
//
//  Created by David Sanchez on 31/10/24.
//

import UIKit
import Combine

class LoginViewController: UIViewController {
    
    
    //MARK: OUTLETS
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    
    //View
    @IBOutlet var viewH: UIView!
    @IBOutlet weak var bodyView: UIView!
    
    //Botones
    @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var logInButton: UIButton!
    
    // ViewModel
    private var loginViewModel = LoginViewModel()
    private var cancellables: Set<AnyCancellable> = []
    
    // MARK: - Ciclo de Vida
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        setupBindings()
    }
    
    // MARK: - Configurar Enlaces con el ViewModel
    private func setupBindings() {
        loginViewModel.$errorMessage
            .sink { [weak self] errorMessage in
                guard let self = self, let message = errorMessage else { return }
                self.showAlert(title: "Error", message: message)
            }
            .store(in: &cancellables)
        
        loginViewModel.$isAuthenticated
            .sink { [weak self] isAuthenticated in
                guard let self = self, isAuthenticated else { return }
                self.navigateToCourseList()
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Tap en Log In
    @IBAction func tapOnLogin(_ sender: UIButton) {
        guard validateFields() else { return }
        loginViewModel.email = emailTextField.text ?? ""
        loginViewModel.password = passwordTextField.text ?? ""
        loginViewModel.login { success in
            if !success {
                self.showAlert(title: "Error", message: self.loginViewModel.errorMessage ?? "Error desconocido.")
            }
            else{
                self.navigateToCourseList()
            }
        }
    }
    
    // MARK: - Validación de Campos
    private func validateFields() -> Bool {
        guard let email = emailTextField.text, !email.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            showAlert(title: "Campos Vacíos", message: "Por favor, completa todos los campos.")
            return false
        }
        
        guard isValidEmail(email) else {
            showAlert(title: "Correo Inválido", message: "Por favor, ingresa un correo válido.")
            return false
        }
        
        return true
    }
    
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegex = "^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: email)
    }
    
    // MARK: - Navegación
    private func navigateToCourseList() {
        guard let courseListViewController = storyboard?.instantiateViewController(withIdentifier: "CourseListViewController") as? CourseListViewController else {
            return
        }
        navigationController?.pushViewController(courseListViewController, animated: true)
    }
    
    // MARK: - Alert Helper
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    @IBAction func tapOnRegister(_ sender: Any) {
        let registerViewController = RegisterViewController()
        navigationController?.pushViewController(registerViewController, animated: true)
    }
}





